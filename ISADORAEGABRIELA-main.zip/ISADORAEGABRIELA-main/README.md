Oi,somos Isadora e Gabriela 😀
👩‍💻 Atualmente estamos estudando no Colégio Estadual Leonilda Papen, no 1 ano do enino médio.
Criamos essa conta para melhor aprendizagem na diciplina de pensamento computacional,e poder deixar nossos trabalhos salvo na plataforma.


 
