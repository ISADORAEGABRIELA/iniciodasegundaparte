body {
  background: #CCCCCC
}

p {
  text-align: center;
}

strong {
  color: red;
}
